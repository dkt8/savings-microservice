import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "path";

// Build outputs to Spring Boot static resources so the app is served by the backend
export default defineConfig({
  plugins: [react()],
  build: {
    outDir: path.resolve(__dirname, "../src/main/resources/static"),
    emptyOutDir: false,
  },
  server: {
    host: "localhost",
    port: 5173,
    proxy: {
      "/api": {
        target: "http://localhost:8087",
        changeOrigin: true,
        secure: false,
      },
    },
  },
});
