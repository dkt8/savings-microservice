This folder contains a Vite + React frontend for Wealth Banking Console.

Quick start:

1. Install dependencies:

```bash
cd frontend
npm install
```

2. Dev server:

```bash
npm run dev
```

3. Build production bundle into Spring Boot static resources:

```bash
npm run build
```

The Vite `build` is configured to output into `src/main/resources/static` so Spring Boot will serve the generated files.
