import React, {useEffect, useState} from 'react'
import Header from './components/Header'
import ProductList from './components/ProductList'
import ProductForm from './components/ProductForm'
import ToastContainer from './components/ToastContainer'
import Confirm from './components/Confirm'
import { fetchProducts, createProduct, updateProduct, deleteProduct } from './api'

export default function App(){
  const [products,setProducts] = useState([])
  const [loading,setLoading] = useState(false)
  const [editing,setEditing] = useState(null)
  const [status,setStatus] = useState('')
  const [toasts,setToasts] = useState([])
  const [confirm,setConfirm] = useState({open:false,message:'',onConfirm:null})
  const nextId = () => Math.random().toString(36).slice(2,9)

  const showToast = (message,type='info') => {
    const id = nextId()
    setToasts(prev=>[...prev,{id,message,type}])
  }
  const removeToast = (id) => setToasts(prev=>prev.filter(t=>t.id!==id))

  const load = async () => {
    try{
      const json = await fetchProducts()
      setProducts(json)
    }catch(err){ setProducts([]) }
  }

  useEffect(()=>{ load() },[])

  const saveProduct = async (payload) => {
    setLoading(true)
    setStatus('')
    try{
      const bodyPayload = {...payload, currency:'VND', depositType:'FIXED_TERM', interestRateType:'FIXED', status:'ACTIVE'}
      if(editing){
        await updateProduct(editing, bodyPayload)
      }else{
        await createProduct(bodyPayload)
      }
      setEditing(null)
      await load()
      const msg = editing ? 'Product updated' : 'Product created'
      setStatus(msg)
      showToast(msg,'success')
    }catch(err){
      console.error(err)
      showToast('Save failed','error')
    }finally{ setLoading(false) }
  }

  const onEdit = (p) => {
    setEditing(p.productCode)
    setStatus('')
  }

  const onCancel = () => { setEditing(null); setStatus('') }

  const onDelete = (codeToDelete) => {
    setConfirm({open:true,message:`Delete ${codeToDelete}?`,onConfirm: async ()=>{
      try{
        const res = await deleteProduct(codeToDelete)
        if(res.status===204){ await load(); setStatus('Product deleted'); showToast('Product deleted','success') }
        else { showToast('Delete failed: '+res.status,'error') }
      }catch(err){ showToast('Delete error','error') }
      setConfirm({open:false,message:'',onConfirm:null})
    }})
  }

  const current = editing ? products.find(p=>p.productCode===editing) : null

  return (
    <div className="app-root">
      <Header />
      <main className="container">
        <section className="panel list-panel">
          <h2>Products <span className="muted">({products.length})</span></h2>
          <div className="status-row">{status}</div>
          <ProductList products={products} onEdit={onEdit} onDelete={onDelete} />
        </section>

        <aside className="panel form-panel">
          <ProductForm initial={current} onSave={saveProduct} onCancel={onCancel} loading={loading} />
        </aside>
      </main>
      <ToastContainer toasts={toasts} onRemove={removeToast} />
      <Confirm open={confirm.open} message={confirm.message} onConfirm={confirm.onConfirm} onCancel={()=>setConfirm({open:false,message:'',onConfirm:null})} />
    </div>
  )
}
