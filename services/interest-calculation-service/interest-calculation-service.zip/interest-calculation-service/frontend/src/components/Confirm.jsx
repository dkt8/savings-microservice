import React from 'react'

export default function Confirm({open, message, onConfirm, onCancel}){
  if(!open) return null
  return (
    <div className="confirm-overlay">
      <div className="confirm-box">
        <div className="confirm-message">{message}</div>
        <div style={{display:'flex',justifyContent:'flex-end',gap:8,marginTop:12}}>
          <button className="btn btn-secondary" onClick={onCancel}>Cancel</button>
          <button className="btn btn-danger" onClick={onConfirm}>Delete</button>
        </div>
      </div>
    </div>
  )
}
