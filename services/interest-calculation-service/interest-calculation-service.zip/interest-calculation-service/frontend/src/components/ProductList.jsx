import React from 'react'

export default function ProductList({products = [], onEdit, onDelete}){
  if(!products || products.length===0) return <div className="empty">No products yet.</div>

  return (
    <ul className="product-list">
      {products.map(p=> (
        <li key={p.productCode} className="product-item">
          <div className="product-main">
            <div>
              <div className="product-code">{p.productCode}</div>
              <div className="product-name">{p.productName}</div>
            </div>
            <div className="product-actions">
              <button className="btn" onClick={()=>onEdit(p)}>Edit</button>
              <button className="btn btn-danger" onClick={()=>onDelete(p.productCode)}>Delete</button>
            </div>
          </div>
        </li>
      ))}
    </ul>
  )
}
