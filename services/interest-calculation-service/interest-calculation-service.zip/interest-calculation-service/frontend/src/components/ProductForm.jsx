import React, {useEffect, useState} from 'react'

export default function ProductForm({initial, onSave, onCancel, loading}){
  const [code,setCode] = useState('')
  const [name,setName] = useState('')
  const [error,setError] = useState('')

  useEffect(()=>{
    if(initial){ setCode(initial.productCode || '') ; setName(initial.productName || '') }
    else { setCode(''); setName('') }
    setError('')
  },[initial])

  const submit = async (e) => {
    e.preventDefault()
    setError('')
    if(!code || !name){ setError('Both code and name are required'); return }
    try{
      await onSave({productCode:code, productName:name})
    }catch(err){
      setError(err?.message || 'Save failed')
    }
  }

  return (
    <form className="form card-form" onSubmit={submit}>
      <h3>{initial ? 'Edit Product' : 'Create Product'}</h3>
      {error && <div className="form-error">{error}</div>}
      <div className="row"><label>Code</label><input value={code} onChange={e=>setCode(e.target.value)} disabled={!!initial} /></div>
      <div className="row"><label>Name</label><input value={name} onChange={e=>setName(e.target.value)} /></div>
      <div className="row">
        <button className="primary" type="submit" disabled={loading}>{loading? (initial? 'Updating...':'Working...') : (initial? 'Update':'Create')}</button>
        {initial && <button type="button" className="btn btn-secondary" onClick={onCancel}>Cancel</button>}
      </div>
    </form>
  )
}
