import React from 'react'

export default function Header(){
  return (
    <header className="app-header">
      <div className="brand">
        <img src="/logo.svg" alt="logo" className="logo"/>
        <div>
          <h1>Banking Console</h1>
          <div className="muted">Product Studio</div>
        </div>
      </div>
    </header>
  )
}
