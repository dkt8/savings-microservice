import React, {useEffect} from 'react'

export default function ToastContainer({toasts = [], onRemove}){
  useEffect(()=>{
    const timers = toasts.map(t => {
      return setTimeout(()=> onRemove(t.id), 4500)
    })
    return () => timers.forEach(clearTimeout)
  },[toasts])

  if(!toasts.length) return null

  return (
    <div className="toast-container">
      {toasts.map(t=> (
        <div key={t.id} className={`toast ${t.type||'info'}`}>
          <div className="toast-message">{t.message}</div>
        </div>
      ))}
    </div>
  )
}
