const API = "/api/v1/saving-products";

export async function fetchProducts() {
  const res = await fetch(API);
  if (!res.ok) throw new Error("Fetch products failed: " + res.status);
  return await res.json();
}

export async function createProduct(payload) {
  const res = await fetch(API, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw res;
  return await res.json();
}

export async function updateProduct(code, payload) {
  const res = await fetch(`${API}/${code}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw res;
  return await res.json();
}

export async function deleteProduct(code) {
  const res = await fetch(`${API}/${code}`, { method: "DELETE" });
  return res;
}
