const API_BASE = "/api/v1/saving-products";

let editing = null;
let currentPage = 1;
let pageSize = 10;
let sortField = null;
let sortDir = 1; // 1 = asc, -1 = desc

async function fetchProducts() {
  const res = await fetch(API_BASE);
  if (!res.ok) return [];
  return await res.json();
}

function qs(id) {
  return document.getElementById(id);
}

function formatCurrency(v) {
  if (v == null) return "";
  try {
    return Number(v).toLocaleString();
  } catch (e) {
    return v;
  }
}

function renderStats(list) {
  qs("totalCount").textContent = list.length;
  qs("activeCount").textContent = list.filter(
    (p) => p.status === "ACTIVE",
  ).length;
  const maturitySet = new Set();
  list.forEach((p) => {
    if (p.maturities)
      p.maturities
        .split(",")
        .map((s) => s.trim())
        .forEach((m) => maturitySet.add(m));
  });
  qs("maturityCount").textContent = maturitySet.size;
}

function renderTable(list) {
  const tbody = qs("productTableBody");
  tbody.innerHTML = "";
  if (list.length === 0) {
    qs("emptyState").hidden = false;
    qs("tableMeta").textContent = "0 sản phẩm";
    qs("pageInfo").textContent = `0 / 0`;
    qs("prevPage").disabled = true;
    qs("nextPage").disabled = true;
    return;
  }
  qs("emptyState").hidden = true;

  // apply sorting
  if (sortField) {
    list.sort((a, b) => {
      const A = (a[sortField] || "").toString().toLowerCase();
      const B = (b[sortField] || "").toString().toLowerCase();
      if (A < B) return -1 * sortDir;
      if (A > B) return 1 * sortDir;
      return 0;
    });
  }

  // pagination
  const total = list.length;
  const totalPages = Math.max(1, Math.ceil(total / pageSize));
  if (currentPage > totalPages) currentPage = totalPages;
  const start = (currentPage - 1) * pageSize;
  const pageItems = list.slice(start, start + pageSize);

  pageItems.forEach((p) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
            <td>${p.productCode || ""}</td>
            <td>${p.productName || ""}</td>
            <td>${p.depositType || ""}</td>
            <td>${p.status || ""}</td>
            <td>${p.interestCalculationMethod || ""}</td>
            <td>
                <button class="action-btn" data-action="edit" data-id="${p.productCode}">Edit</button>
                <button class="action-btn" data-action="delete" data-id="${p.productCode}">Delete</button>
            </td>`;
    tbody.appendChild(tr);
  });
  qs("tableMeta").textContent = `${list.length} sản phẩm`;

  // update pagination UI
  qs("pageInfo").textContent = `${currentPage} / ${totalPages}`;
  qs("prevPage").disabled = currentPage <= 1;
  qs("nextPage").disabled = currentPage >= totalPages;
}

function bindTableActions() {
  qs("productTableBody").addEventListener("click", async (ev) => {
    const btn = ev.target.closest("button");
    if (!btn) return;
    const action = btn.dataset.action;
    const id = btn.dataset.id;
    if (action === "edit") {
      const res = await fetch(`${API_BASE}/${encodeURIComponent(id)}`);
      if (!res.ok) return alert("Không tải được sản phẩm");
      const p = await res.json();
      fillForm(p);
      editing = id;
      qs("formStatus").textContent = "Editing " + id;
    }
    if (action === "delete") {
      if (!confirm("Xác nhận xóa sản phẩm " + id + "?")) return;
      const res = await fetch(`${API_BASE}/${encodeURIComponent(id)}`, {
        method: "DELETE",
      });
      if (res.status === 204) await refresh();
      else alert("Xóa thất bại");
    }
  });
}

function bindSorting() {
  document.querySelectorAll("thead th[data-sort]").forEach((th) => {
    th.addEventListener("click", () => {
      const field = th.getAttribute("data-sort");
      if (sortField === field) sortDir = -sortDir;
      else {
        sortField = field;
        sortDir = 1;
      }
      document
        .querySelectorAll("thead th .sort-indicator")
        .forEach((si) => (si.textContent = ""));
      const si = th.querySelector(".sort-indicator");
      if (si) si.textContent = sortDir === 1 ? "↑" : "↓";
      refresh();
    });
  });
}

function bindPagination() {
  qs("prevPage").addEventListener("click", () => {
    if (currentPage > 1) {
      currentPage--;
      refresh();
    }
  });
  qs("nextPage").addEventListener("click", () => {
    currentPage++;
    refresh();
  });
  qs("pageSizeSelect").addEventListener("change", (e) => {
    pageSize = Number(e.target.value) || 10;
    currentPage = 1;
    refresh();
  });
}

function fillForm(p) {
  qs("productCode").value = p.productCode || "";
  qs("productName").value = p.productName || "";
  qs("currency").value = p.currency || "VND";
  qs("depositType").value = p.depositType || "";
  qs("interestRateType").value = p.interestRateType || "";
  qs("status").value = p.status || "DRAFT";
  qs("maturities").value = p.maturities || "";
  qs("eligibilityRules").value = p.eligibilityRules || "";
  qs("earlyWithdrawalPolicy").value = p.earlyWithdrawalPolicy || "";
  qs("minimumBalance").value = p.minimumBalance || "";
  qs("maximumBalance").value = p.maximumBalance || "";
  qs("interestCalculationMethod").value = p.interestCalculationMethod || "";
  qs("interestPayoutFrequency").value = p.interestPayoutFrequency || "";
  qs("autoRenewalRules").value = p.autoRenewalRules || "";
  qs("taxConfiguration").value = p.taxConfiguration || "";
  qs("submitBtn").textContent = "Cập nhật";
}

function resetForm() {
  qs("productForm").reset();
  editing = null;
  qs("submitBtn").textContent = "Lưu sản phẩm";
  qs("formStatus").textContent = "Ready";
  qs("formStatus").style.color = "";
}

function validateProduct(product) {
  const errors = [];
  if (!product.productCode || product.productCode.length === 0)
    errors.push("Mã sản phẩm không được để trống");
  if (!product.productName || product.productName.length === 0)
    errors.push("Tên sản phẩm không được để trống");
  if (product.minimumBalance && product.maximumBalance) {
    const min = Number(product.minimumBalance);
    const max = Number(product.maximumBalance);
    if (!isNaN(min) && !isNaN(max) && min > max)
      errors.push("Số dư tối thiểu phải <= số dư tối đa");
  }
  return errors;
}

async function handleSubmit(ev) {
  ev.preventDefault();
  const product = {
    productCode: qs("productCode").value.trim(),
    productName: qs("productName").value.trim(),
    currency: qs("currency").value,
    depositType: qs("depositType").value,
    interestRateType: qs("interestRateType").value,
    status: qs("status").value,
    maturities: qs("maturities").value,
    eligibilityRules: qs("eligibilityRules").value,
    earlyWithdrawalPolicy: qs("earlyWithdrawalPolicy").value,
    minimumBalance: qs("minimumBalance").value || null,
    maximumBalance: qs("maximumBalance").value || null,
    interestCalculationMethod: qs("interestCalculationMethod").value,
    interestPayoutFrequency: qs("interestPayoutFrequency").value,
    autoRenewalRules: qs("autoRenewalRules").value,
    taxConfiguration: qs("taxConfiguration").value,
  };
  const validation = validateProduct(product);
  if (validation.length) {
    qs("formStatus").textContent = validation.join("; ");
    qs("formStatus").style.color = "#b91c1c";
    return;
  }

  try {
    let res;
    if (editing) {
      res = await fetch(`${API_BASE}/${encodeURIComponent(editing)}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(product),
      });
      if (res.ok) {
        qs("formStatus").textContent = "Updated";
        await refresh();
        resetForm();
      } else {
        qs("formStatus").textContent = "Update failed";
        alert("Cập nhật thất bại");
      }
    } else {
      res = await fetch(API_BASE, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(product),
      });
      if (res.status === 201) {
        qs("formStatus").textContent = "Created";
        await refresh();
        resetForm();
      } else if (res.status === 409) {
        alert("Mã sản phẩm đã tồn tại");
      } else {
        alert("Tạo thất bại");
      }
    }
  } catch (e) {
    console.error(e);
    alert("Lỗi mạng");
  }
}

async function refresh() {
  const list = await fetchProducts();
  renderStats(list);
  const q = qs("searchInput").value.trim().toLowerCase();
  const filtered = list.filter(
    (p) =>
      !q ||
      (p.productCode && p.productCode.toLowerCase().includes(q)) ||
      (p.productName && p.productName.toLowerCase().includes(q)),
  );
  renderTable(filtered);
}

function bindUI() {
  qs("productForm").addEventListener("submit", handleSubmit);
  qs("resetBtn").addEventListener("click", resetForm);
  qs("searchInput").addEventListener("input", () => refresh());
  bindTableActions();
  bindSorting();
  bindPagination();
}

document.addEventListener("DOMContentLoaded", async () => {
  bindUI();
  await refresh();
});
