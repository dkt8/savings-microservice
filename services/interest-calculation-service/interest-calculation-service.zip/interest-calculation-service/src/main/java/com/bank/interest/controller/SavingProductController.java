package com.bank.interest.controller;

import com.bank.interest.entity.SavingProduct;
import com.bank.interest.repository.SavingProductRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1/saving-products")
public class SavingProductController {

    private final SavingProductRepository repository;

    public SavingProductController(SavingProductRepository repository) {
        this.repository = repository;
    }

    @GetMapping
    public List<SavingProduct> findAll() {
        return repository.findAll();
    }

    @GetMapping("/{productCode}")
    public ResponseEntity<SavingProduct> findById(@PathVariable String productCode) {
        return repository.findById(productCode)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<SavingProduct> create(@RequestBody SavingProduct product) {
        if (product.getProductCode() == null || product.getProductCode().isBlank()) {
            return ResponseEntity.badRequest().build();
        }
        if (repository.existsById(product.getProductCode())) {
            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        }
        SavingProduct saved = repository.save(product);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    @PutMapping("/{productCode}")
    public ResponseEntity<SavingProduct> update(@PathVariable String productCode, @RequestBody SavingProduct product) {
        Optional<SavingProduct> existing = repository.findById(productCode);
        if (existing.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        product.setProductCode(productCode);
        SavingProduct updated = repository.save(product);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{productCode}")
    public ResponseEntity<Void> delete(@PathVariable String productCode) {
        if (!repository.existsById(productCode)) {
            return ResponseEntity.notFound().build();
        }
        repository.deleteById(productCode);
        return ResponseEntity.noContent().build();
    }
}
