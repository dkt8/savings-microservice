package com.bank.interest.entity;

public enum InterestRateType {
    FIXED,
    VARIABLE
}
