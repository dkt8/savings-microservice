package com.bank.interest.entity;

public enum DepositType {
    FIXED_TERM,
    FLEXIBLE_SAVINGS,
    RECURRING_DEPOSIT
}
