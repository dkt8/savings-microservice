package com.bank.interest.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.math.BigDecimal;

@Entity
@Table(name = "saving_products")
public class SavingProduct {

    @Id
    @Column(name = "product_code", nullable = false, length = 64)
    private String productCode;

    @Column(name = "product_name", nullable = false)
    private String productName;

    @Column(nullable = false, length = 3)
    private String currency;

    @Enumerated(EnumType.STRING)
    @Column(name = "deposit_type", nullable = false)
    private DepositType depositType;

    @Enumerated(EnumType.STRING)
    @Column(name = "interest_rate_type", nullable = false)
    private InterestRateType interestRateType;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ProductStatus status;

    @Column(name = "maturities")
    private String maturities;

    @Column(name = "eligibility_rules", length = 1024)
    private String eligibilityRules;

    @Column(name = "minimum_balance", precision = 19, scale = 4)
    private BigDecimal minimumBalance;

    @Column(name = "maximum_balance", precision = 19, scale = 4)
    private BigDecimal maximumBalance;

    @Column(name = "interest_calculation_method")
    private String interestCalculationMethod;

    @Column(name = "interest_payout_frequency")
    private String interestPayoutFrequency;

    @Column(name = "early_withdrawal_policy")
    private String earlyWithdrawalPolicy;

    @Column(name = "auto_renewal_rules")
    private String autoRenewalRules;

    @Column(name = "tax_configuration")
    private String taxConfiguration;

    public SavingProduct() {
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public DepositType getDepositType() {
        return depositType;
    }

    public void setDepositType(DepositType depositType) {
        this.depositType = depositType;
    }

    public InterestRateType getInterestRateType() {
        return interestRateType;
    }

    public void setInterestRateType(InterestRateType interestRateType) {
        this.interestRateType = interestRateType;
    }

    public ProductStatus getStatus() {
        return status;
    }

    public void setStatus(ProductStatus status) {
        this.status = status;
    }

    public String getMaturities() {
        return maturities;
    }

    public void setMaturities(String maturities) {
        this.maturities = maturities;
    }

    public String getEligibilityRules() {
        return eligibilityRules;
    }

    public void setEligibilityRules(String eligibilityRules) {
        this.eligibilityRules = eligibilityRules;
    }

    public BigDecimal getMinimumBalance() {
        return minimumBalance;
    }

    public void setMinimumBalance(BigDecimal minimumBalance) {
        this.minimumBalance = minimumBalance;
    }

    public BigDecimal getMaximumBalance() {
        return maximumBalance;
    }

    public void setMaximumBalance(BigDecimal maximumBalance) {
        this.maximumBalance = maximumBalance;
    }

    public String getInterestCalculationMethod() {
        return interestCalculationMethod;
    }

    public void setInterestCalculationMethod(String interestCalculationMethod) {
        this.interestCalculationMethod = interestCalculationMethod;
    }

    public String getInterestPayoutFrequency() {
        return interestPayoutFrequency;
    }

    public void setInterestPayoutFrequency(String interestPayoutFrequency) {
        this.interestPayoutFrequency = interestPayoutFrequency;
    }

    public String getEarlyWithdrawalPolicy() {
        return earlyWithdrawalPolicy;
    }

    public void setEarlyWithdrawalPolicy(String earlyWithdrawalPolicy) {
        this.earlyWithdrawalPolicy = earlyWithdrawalPolicy;
    }

    public String getAutoRenewalRules() {
        return autoRenewalRules;
    }

    public void setAutoRenewalRules(String autoRenewalRules) {
        this.autoRenewalRules = autoRenewalRules;
    }

    public String getTaxConfiguration() {
        return taxConfiguration;
    }

    public void setTaxConfiguration(String taxConfiguration) {
        this.taxConfiguration = taxConfiguration;
    }
}
