package com.bank.interest.entity;

public enum ProductStatus {
    DRAFT,
    ACTIVE,
    SUSPENDED,
    CLOSED
}
